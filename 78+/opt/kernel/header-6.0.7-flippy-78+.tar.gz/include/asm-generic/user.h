#ifndef __ASM_GENERIC_USER_H
#define __ASM_GENERIC_USER_H
/*
 * This file may define a 'struct user' structure. However, it is only
 * used for a.out files, which are not supported on new architectures.
 */

#endif	/* __ASM_GENERIC_USER_H */
